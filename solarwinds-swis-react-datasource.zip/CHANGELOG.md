# Changelog

## 1.0.0 (2023-05-02)

Initial release of the SolarWinds SWIS React DataSource for Grafana.

### Features
- Query SolarWinds SWIS API
- Support for SWQL queries
- Variable templating
- Custom query builder interface